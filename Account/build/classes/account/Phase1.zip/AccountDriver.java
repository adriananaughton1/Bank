package account;

/*
 * Adriana Naughton, Gabby Turco, Drew Huth
 * AccountDriver
 * 
 */
import java.util.Scanner;


public class AccountDriver {
    public static void main(String[] args) {
        Account student1 = new Account("White", "Jessie", 'F', "2/21",'c', 1);
        Account student2 = new Account("Pinkman", "Walter", 'M', "9/13",'s', 1, 25937.76);
        Account faculty1 = new Account("Dixon", "Rick", 'M', "221",'c', 2);
        Account faculty2 = new Account("Grimes", "Lori", 'F', "221",'s', 2, 52263.43);
        Account staff1 = new Account("Greene", "Daryl", 'M', "221",'c', 3, 832.5);
        Account accounts[] = new Account[5];
        accounts[0] = student1;
        accounts[1] = student2;
        accounts[2] = faculty1;
        accounts[3] = faculty2;
        accounts[4] = staff1;
        Scanner scan = new Scanner(System.in);
        
        boolean condition = true;
        while(condition){
            System.out.println("1) Display all accounts\n2) Make a deposit on an account\n3) Make a withdrawal from an account\n4) Add interest to all accounts"
                + "\n5) Total number of accounts\n6) Exit");
        System.out.print("Choose(1,2,3,4,5, or 6): ");
        int num = scan.nextInt();
            switch (num) {
                case 1:
                    for(Account a: accounts){
                        System.out.println(a);
                    }   break;
                case 2:
                    {
                        boolean num_input = true;
                        while(num_input){
                            System.out.print("Type in your account number: ");
                            int acc_num = scan.nextInt();
                            int count = 0;
                            for (Account a: accounts){
                                count += 1;
                                if (a.getAccountNumber() == acc_num){
                                    System.out.print("How much would you like to deposit: ");
                                    double dep = scan.nextDouble();
                                    a.Deposit(dep);
                                    System.out.println("Your new balance is " + a.getBalance());
                                    num_input = false;
                                    break;
                                }else if (count == 5 && a.getAccountNumber() != acc_num){
                                    System.out.println("Please enter a valid account number.");
                                }
                            }
                        }       
                    }break;
                case 3:
                    {
                        boolean num_input = true;
                        while(num_input){
                            System.out.print("Type in your account number: ");
                            int acc_num = scan.nextInt();
                            int count = 0;
                            for (Account a: accounts){
                                count += 1;
                                if (a.getAccountNumber() == acc_num){
                                    System.out.print("How much would you like to withdraw: ");
                                    double dep = scan.nextDouble();
                                    a.Withdrawal(dep);
                                    System.out.println("Your new balance is " + a.getBalance());
                                    num_input = false;
                                    break;
                                }else if (count == 5){
                                    System.out.println("Please enter a valid account number.");
                                }
                            }                       
                        }       break;
                    }
                case 4:
                    for (Account a: accounts){
                        a.addInterests();
                    }   
                    for(Account a: accounts){
                        System.out.println(a);
                    }   break;
                case 5:
                    int savings = 0;
                    int checkings = 0;
                    int students = 0;
                    int employees = 0;
                    for(Account a: accounts){
                        if (a.getAccountType() == 's'){
                            savings += 1;
                        }else{
                            checkings += 1;
                        }
                    }
                    for(Account a: accounts){
                         if(a.getPerson() == 1){
                             students += 1;
                         }else{
                             employees += 1;
                         }
                    }
                    
                    System.out.println("Number of Savings accounts: " + savings);
                    System.out.println("Number of Checking accounts: " + checkings);
                    System.out.println("Number of student accounts: " + students);
                    System.out.println("Number of employee accounts: " + employees);
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }
    }
}
