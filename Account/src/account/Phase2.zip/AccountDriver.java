package account;

/*
 * Adriana Naughton, Gabby Turco, Drew Huth
 * AccountDriver
 * 
 */

import java.util.*;

public class AccountDriver {
    public static void main(String[] args) {
        Account student1 = new Account("White", "Jessie", 'F', "02/21",'c', 1);
        Account student2 = new Account("Pinkman", "Walter", 'M', "09/13",'s', 1, 25937.76);
        Account student3 = new Account("Williams", "John", 'M', "01/08",'c', 1);
        Account student4 = new Account("Mack", "Tom", 'M', "10/23",'s', 1, 25937.76);
        Account student5 = new Account("Johnson", "Steph", 'F', "12/09",'c', 1);
       
        Account faculty1 = new Account("Dixon", "Rick", 'M', "04/02",'c', 2);
        Account faculty2 = new Account("Grimes", "Lori", 'F', "11/20",'s', 2, 52263.43);
        Account faculty3 = new Account("Reed", "Tony", 'M', "01/18",'c', 2, 6790.34);
        Account faculty4 = new Account("Kennedy", "Anthony", 'M', "09/19",'s', 2, 7899.50);
        Account faculty5 = new Account("Anderson", "Nick", 'M', "08/23",'c', 2);
       
        Account staff1 = new Account("Greene", "Daryl", 'M', "05/01",'c', 3, 832.5);
        Account staff2 = new Account("Hansen", "Bryson", 'M', "06/02",'s', 3, 10976.59);
        Account staff3 = new Account("Powers", "Jordan", 'M', "07/14",'c', 3, 1000.5);
        Account staff4 = new Account("Devlin", "Alex", 'M', "03/21",'s', 3, 750.63);
        Account staff5 = new Account("Gaines", "Debra", 'F', "12/23",'c', 3, 9089.23);
       
        Account accounts[] = new Account[15];
        accounts[0] = student1;
        accounts[1] = student2;
        accounts[2] = student3;
        accounts[3] = student4;
        accounts[4] = student5;
       
        accounts[5] = faculty1;
        accounts[6] = faculty2;
        accounts[7] = faculty3;
        accounts[8] = faculty4;
        accounts[9] = faculty5;
       
        accounts[10] = staff1;
        accounts[11] = staff2;
        accounts[12] = staff3;
        accounts[13] = staff4;
        accounts[14] = staff5;
       
       
        Scanner scan = new Scanner(System.in);
       
        boolean condition = true;
        while(condition){
            System.out.println("1) Display all accounts\n2) Total number of accounts\n3) Make a deposit to an account "
                    + "\n4) Make a withdrawal from an account\n5) Add interest to all accounts "
                    + "\n6) All student accounts with balance less than $100\n7) All employee accounts with balance more than $5000 "
                    + "\n8) Search By Last Name \n9) All Savings Accounts \n10) Exit");
        System.out.print("Choose(1-10): ");
        int num = scan.nextInt();
            switch (num) {
                case 1:
                    for(Account a: accounts){
                        if(a != null){
                            System.out.println(a);
                        }
                    }   break;
                case 2:
                    int savings = 0;
                    int checkings = 0;
                    int students = 0;
                    int employees = 0;
                    for(Account a: accounts){
                        if (a.getAccountType() == 's'){
                            savings += 1;
                        }else{
                            checkings += 1;
                        }
                    }
                    for(Account a: accounts){
                         if(a.getPerson() == 1){
                             students += 1;
                         }else{
                             employees += 1;
                         }
                    }
                    boolean not_valid = true;
                    while (not_valid){
                        System.out.println("\t1) Number of Savings Accounts \n\t2) Number of Checking Accounts "
                                + "\n\t3) Number of Student Accounts \n\t4) Number of Employee Accounts \n\t5) Back to main menu");
                        System.out.print("Choose(1,2,3,4,or 5): ");
                        int num2= scan.nextInt();
                            switch(num2){
                                case 1:
                                    System.out.println("Number of Savings Accounts: " + savings);
                                    not_valid = false;
                                    break;
                                case 2:
                                    System.out.println("Number of Checking Accounts: " + checkings);
                                    not_valid = false;
                                    break;
                                case 3:
                                    System.out.println("Number of Student Accounts: " + students);
                                    not_valid = false;
                                    break;
                                case 4:
                                    System.out.println("Number of employee accounts: " + employees);
                                    not_valid = false;
                                    break;
                                case 5:
                                    not_valid = false;
                                    break;
                                default:
                                    System.out.println("Please enter a valid number.");
                                    break;

                            }
                    }break;
         
                case 3:
                    {
                        boolean num_input = true;
                        while(num_input){
                            System.out.print("Search by: "+ "\n\t1) Account Number \n\t2) Account Name \n\t3) Back to Main Menu \n");
                            System.out.print("Choose(1,2,or 3): ");
                            int num3 = scan.nextInt();
                            switch (num3){
                                case 1:
                                    boolean not_valid1 = true;
                                    while (not_valid1){
                                        int count = 0;
                                        System.out.print("Type in your account number: ");
                                        int acc_num = scan.nextInt();
                                        for (Account a: accounts){
                                            count += 1;
                                            if (a.getAccountNumber() == acc_num){
                                                System.out.print("How much would you like to deposit: ");
                                                double dep = scan.nextDouble();
                                                a.Deposit(dep);
                                                System.out.println("Your new balance is " + a.getBalance());
                                                not_valid1 = false;
                                                num_input = false;
                                                break;
                                            }else if (count == accounts.length && a.getAccountNumber() != acc_num){
                                                System.out.println("Please enter a valid account number.");
                                                
                                            }
                                        }
                                    }break;
                                    
                                case 2:
                                    boolean not_valid2 = true;
                                    while (not_valid2){
                                        int count = 0;
                                        System.out.print("Please enter Last Name: ");
                                        String acc_name= scan.next();
                                        for (Account a: accounts){
                                            count += 1;
                                            if (a.getLastname().toLowerCase().equals(acc_name.toLowerCase())){
                                                System.out.print("How much would you like to deposit: ");
                                                double dep = scan.nextDouble();
                                                a.Deposit(dep);
                                                System.out.println("Your new balance is " + a.getBalance());
                                                not_valid2 = false;
                                                num_input = false;
                                                break;
                                            }else if (count == accounts.length){
                                                System.out.println("Please enter a valid account name.");
                                            }  
                                        }
                                    }break;
                                case 3:
                                    num_input= false;
                                    break;
                                default:
                                    System.out.println("Please enter a valid number.");
                                    break;
                            }  
                          }
                        }break;
                case 4:
                    {
                        boolean num_input = true;
                        while(num_input){
                           
                            System.out.print("Search by: "+ "\n\t1) Account Number \n\t2) Account Name \n\t3) Back to Main Menu \n");
                            System.out.print("Choose(1,2,or 3): ");
                            int num4 = scan.nextInt();
                            switch (num4){
                                case 1:
                                    boolean not_valid1 = true;
                                    while (not_valid1){
                                        int count = 0;
                                        System.out.print("Please enter Account Number: ");
                                        int acc_num= scan.nextInt();
                                        for (Account a: accounts){
                                            count += 1;
                                            if (a.getAccountNumber() == acc_num){
                                                System.out.print("How much would you like to withdraw: ");
                                                double dep = scan.nextDouble();
                                                a.Withdrawal(dep);
                                                System.out.println("Your new balance is " + a.getBalance());
                                                not_valid1 = false;
                                                num_input = false;
                                                break;
                                            }else if (count == 15){
                                                System.out.println("Please enter a valid account number.");
                                            }
                                        }
                                    }break;
                                case 2:
                                    boolean not_valid2 = true;
                                    while (not_valid2){
                                        int count = 0;
                                        System.out.print("Please enter Last Name: ");
                                        String acc_name= scan.next();
                                        for (Account a: accounts){
                                            count += 1;
                                            if (a.getLastname().toLowerCase().equals(acc_name.toLowerCase())){
                                                System.out.print("How much would you like to withdraw: ");
                                                double dep = scan.nextDouble();
                                                a.Withdrawal(dep);
                                                System.out.println("Your new balance is " + a.getBalance());
                                                not_valid2 = false;
                                                num_input = false;
                                                break;
                                            }else if (count == 15){
                                                System.out.println("Please enter a valid account name.");
                                            }
                                        }
                                    }break;
                                case 3:
                                    num_input=false;
                                    break;
                                default:
                                    System.out.println("Please enter a valid number.");
                                    break;
                               
                            }                      
                        }       break;
                    }
                case 5:
                    for (Account a: accounts){
                        a.addInterests();
                    }  
                    for(Account a: accounts){
                        System.out.println(a);
                    }   break;
                case 6:
                    for (Account a: accounts){
                        if( a.getPerson()== 1 && a.getBalance()<100){
                           System.out.println(a);
                        }
                    }break;
                case 7:
                    for (Account a: accounts){
                        if( a.getPerson()== 2 || a.getPerson()== 3 ){
                           if (a.getBalance()> 5000){
                               System.out.println(a);
                           }
                        }
                    }break;
                case 8:
                    boolean go = true;
                    while (go){
                        System.out.print("What is your last name?: ");
                        String lname = scan.next();
                        int target = Account.LinearSearch(accounts, lname);
                        if(target == -1){
                            System.out.println("Please enter a valid last name.");
                        }else{
                            System.out.print(accounts[target]);
                            boolean not_valid3 = true;
                            while(not_valid3){
                                System.out.print("1) Check balance\n2) Withdraw money\n3) Deposit money\n4) Add interest "
                                        + "\n5) Close (Delete) the account\n6) Back to main menu\nChoose(1-6): ");
                                int choice = scan.nextInt();
                                switch(choice){
                                    case 1:
                                        System.out.println("Your balance is: " + accounts[target].getBalance());
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    case 2:
                                        System.out.print("How much would you like to withdraw: ");
                                        double money = scan.nextDouble();
                                        accounts[target].Withdrawal(money);
                                        System.out.println("Your new balance is " + accounts[target].getBalance());
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    case 3:
                                        System.out.print("How much would you like to deposit: ");
                                        double d = scan.nextDouble();
                                        accounts[target].Deposit(d);
                                        System.out.println("Your new balance is " + accounts[target].getBalance());
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    case 4:
                                        accounts[target].addInterests();
                                        System.out.println("Your new balance is " + accounts[target].getBalance());
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    case 5:
                                        accounts[target] = null;
                                        System.out.println("Account has been deleted.");
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    case 6:
                                        not_valid3 = false;
                                        go = false;
                                        break;
                                    default:
                                        System.out.println("Please enter a valid number.");
                                        break;
                                }
                            }
                        }
                    }break;
                case 9:
                    Account temp;
                    for(int i = accounts.length - 1; i >= 0; i--){
                        for(int j = 0; j <= i - 1; j++){
                            if(accounts[j].getFirstname().compareTo(accounts[j + 1].getFirstname()) > 0){
                                temp = accounts[j];
                                accounts[j] = accounts[j + 1];
                                accounts[j + 1] = temp;
                            }
                        }
                    }
                    for(Account a: accounts){
                        if(a.getAccountType() == 's'){
                            System.out.print(a);
                        }
                    }break;
                case 10:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please enter a valid number.");
                    break;
            }
        }
    }
    
}